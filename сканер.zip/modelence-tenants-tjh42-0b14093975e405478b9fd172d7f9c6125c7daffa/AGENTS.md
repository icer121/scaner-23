## Design Style Guide (`DESIGN.md`)

`DESIGN.md` at the project root is the app's durable design brief: the aesthetic
direction, color palette, font pairing, spacing/radius conventions, and animation
utilities. `src/client/index.css` (Tailwind configured CSS-first via the `@theme`
directive) is where those decisions live as code. Read `DESIGN.md` before any UI
work, and whenever you make or change a design decision, update it to match so
the brief always reflects the real design.

**If `DESIGN.md` is still the starter placeholder (marked `STATUS: NOT
ESTABLISHED`), the app has no design identity yet.** Before implementing any
functionality, you MUST establish a unique design identity for this app:

1. **Choose a distinctive aesthetic direction** based on the app's purpose and
   audience. Consider the tone: is it playful, professional, editorial,
   minimalist, bold, warm, technical, luxurious? Each app should feel different.
2. **Create a style guide** by updating `src/client/index.css` with:
   - A custom color palette defined as `@theme` tokens (avoid generic blue/gray
     — pick colors that match the app's personality)
   - A distinctive font pairing imported from Google Fonts (one display/heading
     font + one body font — avoid Inter, Roboto, Arial)
   - A spacing and border-radius convention that fits the aesthetic
   - Smooth transitions and animations: define reusable animation keyframes and
     `@theme` `--animate-*` utilities (e.g. fade-in, slide-up, staggered
     reveals) for consistent motion across the app
3. **Rewrite `DESIGN.md`** with the actual design brief, replacing the
   placeholder contents entirely (including the `STATUS: NOT ESTABLISHED`
   block): the aesthetic direction and rationale, the color palette (token
   names + values), the font pairing, spacing/radius conventions, and the
   animation utilities. This marks the design identity as established.
4. **Replace the starter template completely — every starter surface, not just
   the home page.** The default HomePage, the shared `Page` wrapper and its
   header/nav, and the Login and Signup pages are all generic placeholders.
   Restyle ALL of them to your chosen aesthetic in this first build — a common
   failure is theming only HomePage and leaving the shared wrapper and auth
   pages on the old generic gray/black template, which makes the app feel
   half-finished. Build the UI from scratch; do not inherit styles or layout
   patterns from the template. If a starter surface exists that isn't listed
   here, restyle it too.

Do this as your first step, before writing any feature code. `DESIGN.md` and the
updated `src/client/index.css` must be part of the same turn's changes so they
are committed together. All subsequent UI work must follow this style guide.

## Comprehensive Project Structure Overview

### 1. PROJECT STRUCTURE

```
/user-app/
├── src/
│   ├── client/                      # React frontend (React 19)
│   │   ├── assets/                  # Images/logos (favicon.svg, modelence.svg)
│   │   ├── components/
│   │   │   ├── ui/                  # Reusable UI components (shadcn-style, on Base UI)
│   │   │   │   ├── _shared/         # sizes.ts, variants.ts, buttonGroup.ts (design tokens)
│   │   │   │   ├── Button.tsx        # variant × color × size, render, loading
│   │   │   │   ├── IconButton.tsx    # square icon-only button (same sizes as Button)
│   │   │   │   ├── ButtonGroup.tsx   # segmented Button/IconButton group
│   │   │   │   ├── Input.tsx
│   │   │   │   ├── Textarea.tsx
│   │   │   │   ├── Label.tsx
│   │   │   │   ├── Badge.tsx
│   │   │   │   ├── Card.tsx
│   │   │   │   ├── Spinner.tsx       # inline spinner glyph (for controls)
│   │   │   │   ├── Checkbox.tsx
│   │   │   │   ├── Switch.tsx
│   │   │   │   ├── RadioGroup.tsx
│   │   │   │   ├── Select.tsx
│   │   │   │   ├── Dialog.tsx
│   │   │   │   ├── DropdownMenu.tsx
│   │   │   │   ├── Tabs.tsx
│   │   │   │   ├── Tooltip.tsx
│   │   │   │   ├── Avatar.tsx
│   │   │   │   └── Separator.tsx
│   │   │   ├── LoadingSpinner.tsx    # Page-level loading component (uses ui/Spinner)
│   │   │   ├── Page.tsx              # Page wrapper with header (accepts `seo` prop)
│   │   │   └── Seo.tsx               # Renders <title> via React 19 native metadata
│   │   ├── pages/                    # Route pages
│   │   │   ├── HomePage.tsx
│   │   │   ├── LoginPage.tsx
│   │   │   ├── SignupPage.tsx
│   │   │   ├── ExamplePage.tsx
│   │   │   ├── PrivateExamplePage.tsx
│   │   │   ├── LogoutPage.tsx
│   │   │   ├── TermsPage.tsx
│   │   │   └── NotFoundPage.tsx
│   │   ├── lib/
│   │   │   ├── utils.ts              # Utility functions (cn helper)
│   │   │   └── autoLogin.ts          # Sandbox auto-login hook
│   │   ├── router.tsx                # React Router configuration
│   │   ├── seo.config.ts             # Single source of truth for site name / <title>
│   │   ├── index.tsx                 # App entry point
│   │   ├── types.d.ts
│   │   └── index.css
│   │
│   └── server/                       # Node.js backend
│       ├── app.ts                    # Server entry point
│       ├── example/
│       │   ├── index.ts              # Module definition with queries/mutations
│       │   ├── db.ts                 # Database schemas
│       │   └── cron.ts               # Scheduled jobs
│       └── migrations/
│           └── createDemoUser.ts     # Seeds the sandbox demo user
│
├── DESIGN.md                         # Design style guide (durable design brief)
│
├── Configuration Files
│   ├── tsconfig.json                 # TypeScript 
│   ├── vite.config.ts                # Vite bundler config (loads @tailwindcss/vite)
│   └── modelence.config.ts           # Modelence framework config
│
└── package.json                      # Dependencies & scripts
```

### 2. AVAILABLE UI COMPONENTS (SHADCN-STYLE, ON BASE UI)

Located in `/user-app/src/client/components/ui/`. Interactive primitives wrap
**Base UI** (`@base-ui/react`, unstyled, accessible — keyboard nav, focus
management, Esc/Space/arrow handling come for free). Style is applied via
Tailwind + `data-*` state attributes. Plain controls (Button, Input, etc.) are
styled native elements. **No barrel index** — import each from its own file.

#### Design tokens — single source of truth (`ui/_shared/`)
Edit these to retune the whole library; every control reads from them.
- **`sizes.ts`** — control sizes `sm | md | lg`. `SIZES` (text controls),
  `ICON_SIZES` (square icon controls), `ICON_GLYPH` (inline icon px). Heights
  are shared (`sm=h-8 / md=h-9 / lg=h-10`) so an `sm` Button lines up with an
  `sm` Input/Select/IconButton. **Keep `h-*` in sync between the two maps.**
- **`variants.ts`** — `variant` (style: `solid | outline | ghost | link | soft`)
  × `color` (intent: `neutral | primary | destructive`). `solid`+`neutral` is
  the default black button. `CONTROL_BASE` holds shared base + focus ring +
  `cursor-pointer`.
- **`buttonGroup.ts`** — context for ButtonGroup → child size/variant/color.

#### Buttons
- **`Button.tsx`** — `variant`, `color`, `size`, `loading`, `leftIcon`,
  `rightIcon`, `render` (polymorphism via Base UI `useRender` — replaces the old
  `asChild`). No `size="icon"` (use IconButton). Migration from old API:
  `default`→solid/neutral · `destructive`→solid+destructive ·
  `secondary`→soft+neutral · `outline`/`ghost`/`link`→same `variant`.
- **`IconButton.tsx`** — square icon-only button, same `sm/md/lg` heights and
  `variant`×`color` as Button. **`aria-label` is required** (enforced by types).
- **`ButtonGroup.tsx`** — segmented group that fuses inner radii/borders. Holds
  Button/IconButton **and** form controls (Input, Textarea, Select trigger) as
  siblings, e.g. an Input with attached buttons (matches shadcn's ButtonGroup).
  Props `orientation` (`horizontal`|`vertical`), `size`, `variant`, `color`
  (propagated to child Button/IconButton; a child's own prop wins).

#### Form controls (sizes align with Button)
- **`Input.tsx`** — `size?: ControlSize`. (Native numeric `size` is omitted.)
- **`Textarea.tsx`** — multi-line, `min-h-16`.
- **`Label.tsx`** — shadcn-style: `flex items-center gap-2`, peer/group-disabled.
- **`Checkbox.tsx`** — Base UI; Space toggles; supports `indeterminate`.
- **`Switch.tsx`** — Base UI toggle.
- **`RadioGroup.tsx`** — `RadioGroup` + `RadioGroupItem`; arrow-key roving focus.
- **`Select.tsx`** — single component: `<Select options={[{label,value,disabled}]}
  value onValueChange placeholder size />`. Shows the selected option's label in
  the closed trigger (via Base UI `items`). Optional `renderItem` for custom rows.

#### Overlays & navigation
- **`Dialog.tsx`** — `Dialog`, `DialogTrigger`, `DialogContent` (Esc-closes,
  focus-trapped, built-in close button), `DialogTitle`, `DialogDescription`,
  `DialogHeader`, `DialogFooter`, `DialogClose`.
- **`DropdownMenu.tsx`** — `DropdownMenu`, `DropdownMenuTrigger`,
  `DropdownMenuContent`, `DropdownMenuItem`, `DropdownMenuLabel` (standalone,
  use anywhere), `DropdownMenuSeparator`, `DropdownMenuGroup` +
  `DropdownMenuGroupLabel` (the label MUST be inside a Group).
- **`Tabs.tsx`** — `Tabs`, `TabsList`, `TabsTab`, `TabsPanel`.
- **`Tooltip.tsx`** — `Tooltip`, `TooltipTrigger`, `TooltipContent`. Requires
  **`TooltipProvider`**, already mounted once at the app root in `index.tsx`.

#### Display
- **`Card.tsx`** — `Card`, `CardHeader`, `CardTitle`, `CardDescription`,
  `CardAction` (top-right header slot), `CardContent`, `CardFooter`.
- **`Badge.tsx`** — `variant` (`solid|soft|outline`) × `color`.
- **`Avatar.tsx`** — `Avatar`, `AvatarImage`, `AvatarFallback`.
- **`Separator.tsx`** — `orientation` (`horizontal`|`vertical`).
- **`Spinner.tsx`** — inline spinner glyph (use inside controls). For page-level
  loading use `components/LoadingSpinner` (which renders a `Spinner`).

All components use the `cn()` utility for class merging. New interactive
primitives are client components (`"use client"`). The app root sets
`isolation: isolate` (in `index.css`) so portalled popups stack correctly.

### 3. UTILITY FUNCTIONS

**File**: `/user-app/src/client/lib/utils.ts`

```typescript
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}
```
- Uses `clsx` for conditional classes
- Uses `tailwind-merge` to prevent class conflicts
- Perfect for merging component classes with custom overrides

### 4. EXISTING FORM PATTERNS

The app already has two working form examples you can reference:

#### LoginForm (`/user-app/src/client/pages/LoginPage.tsx`)
- Email and password fields
- `FormData` API for form submission
- Card-based layout with headers and footers
- Validation and error handling
- Links to signup

#### SignupForm (`/user-app/src/client/pages/SignupPage.tsx`)
- Email, password, confirm password
- Checkbox for terms acceptance
- Success state handling
- Client-side password validation
- Toast error notifications
- `useCallback` hook for form submission
- State management for success state

### 5. APP STRUCTURE & ARCHITECTURE

#### Client Setup (`/user-app/src/client/index.tsx`)
```typescript
- React Query (TanStack) integration
- React Router DOM
- React Hot Toast for notifications
- Suspense boundaries with loading state
- Global error handler
```

#### Router Configuration (`/user-app/src/client/router.tsx`)
- **Public Routes**: Home, Example, Terms, Logout, 404
- **Guest Routes**: Login, Signup (redirects to home if authenticated)
- **Private Routes**: PrivateExamplePage (redirects to login if not authenticated)
- **Route Protection**: 
  - `GuestRoute` component for auth-only pages
  - `PrivateRoute` component for protected pages
  - Redirect with `_redirect` query param to return after login

#### Page Wrapper (`/user-app/src/client/components/Page.tsx`)
- Header with a Home button (left) and either user handle + Logout or a Sign in button (right) — no logo
- Responsive layout with max-width
- Body section with optional loading state
- Accepts a `seo` prop (`{ title?, noindex? }`) that is forwarded to `<Seo />`
  to set the document `<title>` per page (see SEO/TITLE PATTERN below)

### 6. MODULE SYSTEM (Backend)

**File**: `/user-app/src/server/example/index.ts`

Example shows Module pattern with:

```typescript
new Module('example', {
  configSchema: { /* configuration */ },
  stores: [ /* database stores */ ],
  queries: {
    getItem: async (args, { user }) => { /* query logic */ },
    getItems: async (args, { user }) => { /* query logic */ }
  },
  mutations: {
    createItem: async (args, { user }) => { /* mutation logic */ },
    updateItem: async (args, { user }) => { /* mutation logic */ }
  },
  cronJobs: {
    dailyTest: dailyTestCron
  }
})
```

#### Database Pattern (`/user-app/src/server/example/db.ts`)
```typescript
export const dbExampleItems = new Store('exampleItems', {
  schema: {
    title: schema.string(),
    createdAt: schema.date(),
    userId: schema.userId(),
  },
  indexes: []
});
```

### 7. BUILD & DEVELOPMENT

**Scripts** (from package.json):
```bash
npm run dev          # Development server
npm run build        # Production build
npm start            # Start production server
npm test             # Run tests (not configured)
```

**Vite Configuration**:
- Root: `src/client`
- Path alias: `@/` → `./src/`
- Dev server: `0.0.0.0:5173` (allows external access)
- React plugin enabled

### 8. STYLING SETUP

- **Tailwind CSS v4** via the `@tailwindcss/vite` plugin. All Tailwind config
  is CSS-first in `src/client/index.css` (`@import "tailwindcss"`, `@theme`,
  `@source`, etc.) — customize the design system there.
- **Color Scheme**: Gray, black, white primary colors; blue, red accents —
  starter defaults only, meant to be replaced when the design identity is
  established (see "Design Style Guide (`DESIGN.md`)" at the top of this file).

### 9. SEO (TITLE, DESCRIPTION, OG TAGS)

- `src/client/seo.config.ts` is the single source of truth for `siteName` and
  the site-wide meta `description`. **You MUST update both fields** as soon as
  the product name is known — they default to the literal string
  `"Empty Project"` and a generic placeholder description, both of which ship
  broken SEO and social previews. Update them on any landing-page task or
  product-rename request.
- `<Seo />` (in `src/client/components/Seo.tsx`) renders `<title>`, the meta
  description, and Open Graph / Twitter card tags from `seoConfig`. It is
  already mounted once at the app root in `src/client/index.tsx`, so every
  page inherits the site-wide defaults automatically.
- Per-page overrides: pass `seo` to `<Page />`, e.g.
  `<Page seo={{ title: 'Sign in' }}>` or
  `<Page seo={{ title: 'Pricing', description: '...' }}>`. Set
  `noindex: true` for auth, terms, and 404 pages.
- Rendered at runtime via React 19 native `<title>` / `<meta>` hoisting; no
  SEO library needed.
- Heading hierarchy: every page must have exactly one `<h1>` and headings
  must descend monotonically (`h1 → h2 → h3`, never skip a level). Skipped
  levels hurt accessibility audits and SEO.

### 10. REUSABLE PATTERNS FOR NEW FEATURES

When adding a new feature, reach for these existing building blocks before
introducing new ones:

1. **Forms**: native `FormData` API, mirroring `LoginPage` / `SignupPage`.
2. **Validation**: Zod on the server (inside module queries/mutations);
   lightweight client-side checks before submit.
3. **UI Components**: the full set in `src/client/components/ui/` (Button,
   IconButton, ButtonGroup, Input, Textarea, Label, Checkbox, Switch,
   RadioGroup, Select, Dialog, DropdownMenu, Tabs, Tooltip, Card, Badge,
   Avatar, Separator, Spinner). See section 2. Interactive primitives are built
   on `@base-ui/react`; reuse these before adding any external UI library.
4. **Page Layout**: wrap routes in `<Page>` (sets header + `<title>` via
   the `seo` prop).
5. **Icons**: `lucide-react`.
6. **Toast Notifications**: `react-hot-toast` for user feedback.
7. **Server State**: `@tanstack/react-query` via `@modelence/react-query`
   helpers (`useQuery`, `useMutation`).
8. **Local State**: standard React hooks (`useState`, `useCallback`,
   `useMemo`, `useRef`). On React 19, prefer ref-as-prop over `forwardRef`
   in any new components.
9. **Styling**: Tailwind classes combined with the `cn()` helper from
   `src/client/lib/utils.ts`.
10. **Backend feature**: add a new `Module` under `src/server/<feature>/`
    following the `example` module shape (`configSchema`, `stores`,
    `queries`, `mutations`, optional `cronJobs`), and register it in
    `src/server/app.ts`.

### 12. ElliottWave MOEX (project-specific)

This app is a from-scratch Modelence rebuild of an external Python/FastAPI
project ("ElliottWave MOEX") — a premium glassmorphic trading dashboard for
Elliott Wave analysis of Moscow Exchange stocks. Built incrementally per the
"Scoping and incremental delivery" protocol; do not bulk-port the original
spec in one shot.

**Design**: dark glassmorphic trading terminal. See `DESIGN.md` for the full
brief — `#0b0f19`/`#111827` backgrounds, `.glass-card` utility (bg-slate-900/60
+ backdrop-blur-xl + border-white/5), neon signal colors (`--color-long`
`#00ffa3` / `--color-short` `#ff4a5a` / `--color-ai` `#6366f1`), Space Grotesk
(display) + JetBrains Mono (`.font-mono-tabular`, for all numeric data).
`Page.tsx`, `LoginPage.tsx`, `SignupPage.tsx` were restyled to match (no
longer the generic light starter theme).

**Backend** — `src/server/elliottwave/`:
- `moex.ts` — `fetchOHLCV(symbol, timeframe, limit)`: fetches OHLCV from MOEX
  ISS (shares via `.../boards/TQBR/securities/{symbol}/candles.json`, indices
  like IMOEX/RTSI via `.../history/engines/stock/markets/index/securities/
  {symbol}.json`). In-memory cache keyed by `symbol:tf:limit`, 60s TTL.
  Resamples 2h/4h/6h/12h/30m from 1h/10m native candles. Bad-tick filter drops
  bars where close deviates >20% from the 5-neighbor median or
  (high-low)/close > 30%.
- `scanners.ts` — ported verbatim (logic-wise) from the original Python
  `backend/scanners.py` found in the user's uploaded archive. Exports
  `SCAN_TICKERS` (95-ticker MOEX watchlist), `scanMaCross(mode, days, tf)`
  (Golden/Death cross of MA50/MA200, strength GOLD/SILVER/WEAK or
  DEAD/WEAK/REVERSED), `scanRange(tf)` (range breakout detection via
  `detectRange()` — width%, touches, position, direction BREAK_UP/BREAK_DOWN,
  stop/target/R:R, strength STRONG/MEDIUM/WEAK), `TF_CONFIG_RANGE` (per-TF
  days_back/min_width/max_width/windows), `mapWithConcurrency()` (bounded
  concurrency helper replacing Python's `ThreadPoolExecutor`), `rollingMean()`.
  Both scanners call `fetchOHLCV` from `moex.ts` per ticker with concurrency
  limits (8 for MA cross, 6 for range) to avoid hammering MOEX ISS.
- `elliott.ts` — Elliott Wave detection engine, ported from the original
  Python `engine.py`. Exports `zigzag(prices, depth, atrMult)` (ZigZag pivot
  detection), `DEGREE_CONFIG` (-1 Cycle / 0 Primary / 1 Intermediate / 2
  Minor, each with depth+ATR-mult), wave detectors (`checkImpulse`,
  `checkDiagonal`, `checkZigzag`, `checkFlat`, `checkTriangle` — Fibonacci-
  ratio scored, internal not exported), `walkChain`/`walkChainSoft` (greedy
  pivot-chain walkers), and the `ElliottAnalyzer` class (`analyze()` runs all
  degrees, returns `Wave[]`; builds `forecast`/`forecastAlt` — ABC retrace +
  alternative continuation — off the most recent impulse/correction).
- `indicators.ts` — MA/RSI/Bollinger/MACD/volume-spike/support-resistance
  computation, ported from the pandas rolling/ewm code in the original
  `/api/waves` handler. `computeIndicators(candles)` returns `{ ma50, ma200,
  rsi, bb_upper, bb_lower, bb_mid, macd_line, macd_signal, macd_hist,
  vol_spikes, levels }`. `levels` are price clusters from local peak/trough
  detection (5-bar window), top 10 by cluster strength.
- `index.ts` — Module `elliottwave` with queries: `getCandles({ symbol, tf,
  limit })` → `{ symbol, tf, ohlc }` (legacy, chart-only slice — still used
  for the raw-candle shape but `getWaves` has superseded it on HomePage);
  `scanMaCross({ mode, days, tf })` and `scanRange({ tf })` (wrap
  `scanners.ts`); `getWaves({ symbol, tf, limit })` → `{ symbol, tf, ohlc,
  waves, forecast, forecast_alt, ma50, ma200, rsi, bb_upper, bb_lower,
  bb_mid, macd_line, macd_signal, macd_hist, vol_spikes, levels }` (runs
  `ElliottAnalyzer` + `computeIndicators` over `fetchOHLCV` candles; anchors
  the forecast's current price to the latest 1h close, same as the Python
  handler). All responses run through a local `cleanNaN()` helper
  (NaN/Infinity → null). No auth required (public market data).

**Frontend**:
- `src/client/components/elliottwave/Chart.tsx` — Lightweight Charts (v5 API:
  `chart.addSeries(CandlestickSeries, opts)`, multi-pane via `addSeries(def,
  opts, paneIndex)`) candlestick chart, now a full wave+indicator renderer.
  Dark theme (`#0e1117` background), green/red candle colors matching the
  signal palette. Pane 0 (main): candles + MA50 (gold)/MA200 (indigo) lines +
  Bollinger upper/lower (dashed gray) + one `LineSeries` per detected wave
  (color by degree: Cycle violet / Primary indigo / Intermediate cyan / Minor
  gold, via `createSeriesMarkers` for the I/II/III/A/B/C point labels) +
  top-5 S/R level price lines (dotted) + TP/SL price lines from the main
  forecast. Pane 1: RSI with 30/70 dotted reference lines. Pane 2: MACD
  histogram + line + signal. All overlays are rebuilt in one `useEffect`
  keyed on the indicator/wave props so they don't leak across re-renders;
  `showWaves`/`showIndicators` booleans let the caller hide either layer.
  `autoSize: true`; candle data updates via `series.setData()` without
  resetting pan.
- `src/client/components/elliottwave/ScannerPanel.tsx` — scanner UI: mode
  tabs (Golden Cross / Death Cross / Range), timeframe pill selector, refresh
  button. `MaCrossTable` and `RangeTable` sub-components render results via
  `modelenceQuery('elliottwave.scanMaCross', ...)` /
  `('elliottwave.scanRange', ...)`, styled to match the glass/neon palette
  (green for LONG/gains, red for SHORT/losses, gold for R:R).
- `src/client/pages/HomePage.tsx` — replaces the starter placeholder. Header
  bar (glass-card) with a Chart/Scanners tab switcher, plus (chart tab only)
  symbol picker (plain `<select>`, deliberately not the shared `ui/Select`
  which is hardcoded light-themed), timeframe pill toggle (1h/4h/1d/1w), a
  Waves/Indicators visibility toggle pair (lucide `Waves`/`Target` icons),
  and reload button. Chart tab now polls `elliottwave.getWaves` (not
  `getCandles`) every 30s, shows live price + session change %, a forecast
  signal card (side/entry/SL/TP/R:R) when the engine has one, and passes
  `ma50/ma200/bb_upper/bb_lower/rsi/macd_*/waves/levels/forecast` through to
  `<Chart>`. Scanners tab renders `ScannerPanel`.

**Known deferred work** (from the original spec, not yet built): consensus
endpoint, dedicated volume panel (vol_spikes are computed in `indicators.ts`
but not yet drawn on the chart), Fib/Ruler drawing tools, TOP-by-R:R panel,
URL-hash tab navigation, Bento Grid full layout. Whale Detector is explicitly
OFF LIMITS for now per user instruction ("пока не трогать Whale Detector") —
it reads a local SQLite file on a Windows machine, unreachable from the cloud
app; do not build or stub it until the user asks.

### Summary

This is a full-stack Modelence framework application with:
- Clean component structure ready for new features
- All necessary UI building blocks already available
- Form handling patterns established
- Database and backend module patterns ready to follow
- Authentication system in place
- TypeScript support throughout
- A shadcn-style component library built on `@base-ui/react` (accessible
  primitives) is already implemented — reuse it before adding any UI library

### 11. MOBILE APP (Expo, optional)

A project may *optionally* include a mobile app alongside the web app. The
template ships an empty `mobile/` folder, but the studio treats the mobile
app as "not yet created" until the marker file
`mobile/.modelence-mobile-enabled` exists. The Mobile tab in the studio shows
a "Create mobile app" CTA in this state.

**Folder layout**

```
project-root/
├── src/server/        # Modelence backend (unchanged)
├── src/client/        # Web client (unchanged)
├── package.json       # Web dependencies (+ postinstall for mobile)
└── mobile/            # Expo / React Native app (shipped but unhooked)
    ├── .modelence-mobile-enabled  # marker file — present once created
    ├── package.json   # Expo's deps (main: "expo-router/entry")
    ├── app.config.js  # Expo config (includes scheme for deep linking)
    ├── index.ts       # configureClient + auth token persistence (side-effect module)
    ├── app/           # Expo Router file-based routes
    │   ├── _layout.tsx          # root layout — SafeAreaProvider, AppProvider, QueryClientProvider, RouteGuard
    │   ├── (auth)/
    │   │   ├── _layout.tsx      # headerless Stack for unauthenticated screens
    │   │   └── sign-in.tsx      # sign-in screen
    │   └── (app)/
    │       ├── _layout.tsx      # headerless Stack for authenticated screens
    │       └── home.tsx         # home screen (requires auth)
    ├── components/    # React Native UI library (RN equivalents of src/client/components/ui)
    │   ├── LoadingSpinner.tsx   # screen-level loading state
    │   └── ui/                  # Button, Input, Card, Dialog, … + _shared/ design tokens
    ├── babel.config.js
    └── tsconfig.json
```

**Important rules**

- The studio's "Create mobile app" flow (button or matching free-text prompt)
  scaffolds/installs the Expo app and writes `mobile/.modelence-mobile-enabled`.
  Do NOT write that marker without first installing Expo dependencies — the
  studio assumes mobile is fully usable once the marker is present.
- The mobile app uses **Expo Router 4.x** (file-based routing). The entry
  point is `expo-router/entry` (set in `mobile/package.json`'s `"main"` field).
  Route groups: `(auth)` for unauthenticated screens, `(app)` for protected
  screens. The `RouteGuard` component in `app/_layout.tsx` redirects based on
  `useSession()` — unauthenticated → `/(auth)/sign-in`, authenticated →
  `/(app)/home`. Do not revert to a manual `registerRootComponent` + `App.tsx`
  setup.
- `index.ts` is a side-effect module (imported by `app/_layout.tsx`) that runs
  `configureClient` and rehydrates the auth token from AsyncStorage. It does
  NOT call `registerRootComponent`.
- **Mobile UI components** live in `mobile/components/ui/` — React Native
  equivalents of the web set in `src/client/components/ui/`, with a parallel
  prop API so the two platforms read as one design system. The full set:
  Button, IconButton, ButtonGroup, Spinner, Input, Textarea, Label, Checkbox,
  Switch, RadioGroup, Select, Tabs, Card, Badge, Avatar, Separator, Dialog,
  DropdownMenu, Tooltip (import from the `mobile/components/ui` barrel). Reuse
  these before adding any external RN UI library. Key differences from web,
  since RN has no Tailwind/Base UI/DOM:
  - Styling is plain `StyleSheet` (no Tailwind/NativeWind). Shared design tokens
    (palette, sizes, variants) live in `mobile/components/ui/_shared/` and mirror
    the web tokens — edit tokens there, not per-component, to restyle globally.
  - There is no `:hover`/`:active`; variant styles model rest + pressed states.
  - Overlays use native primitives: `Select`, `DropdownMenu` present a Modal
    (bottom sheet / action sheet); `Dialog` is a centered Modal; `Tooltip`
    reveals on tap (and hover on web) rather than hover-only. `TooltipProvider`
    is a no-op passthrough kept for API parity.
  - `DropdownMenuTrigger` / `DialogTrigger` / `DialogClose` clone their single
    child and inject `onPress` — pass exactly one pressable element as the child.
- **Expo Go constrains which packages can be added.** The Mobile preview runs
  in stock Expo Go from the App Store, not a custom dev client, so only the
  native modules compiled into its SDK 54 binary exist there, at the versions it
  ships. We cannot upgrade past SDK 54: customers open the preview with the
  store build. Pure-JS packages are always fine.

  **Never run bare `npm install <pkg>` in `mobile/`.** It resolves to `latest`,
  whose native side Expo Go does not have, and the app then boots to a blank
  white screen with **no error** — there is nothing in the logs to debug. Use
  the project-local Expo CLI, which pins to the installed SDK:

  ```
  cd mobile && ./node_modules/.bin/expo install <pkg>
  ```

  Invoke the binary by path. Do NOT use `npx expo` / `npm exec expo` — when the
  local package isn't fully resolvable (exactly the case right after
  `npm install`, since npm extracts package directories before it links bins),
  npm silently downloads the *latest* CLI and runs it against this SDK 54
  project.

  `mobile/node_modules/expo/bundledNativeModules.json` is the name → version map
  of everything Expo Go supports. Before adding a mobile dependency, check it:
  - **Listed** — `expo install` it; it works in the preview.
  - **Not listed, pure JS** (e.g. `lucide-react-native`, which only wraps
    `react-native-svg`) — `npm install` is fine and works in the preview.
  - **Not listed and native** — you MAY still add it, but you MUST warn the user
    BEFORE installing and get their go-ahead. Tell them plainly that the package
    needs native code Expo Go does not have; that the Expo Go preview for this
    app will stop working once it is added (the QR code will no longer boot it);
    and that from then on they need **Publish Mobile App → Android → Test build**
    to get an installable APK. iOS has no test-build path — iOS goes through
    TestFlight / the App Store. Offer a JS-only or Expo-SDK alternative first if
    one exists. If they accept the tradeoff, install it and repeat the warning in
    your closing message. Do not silently install a native package, and do not
    refuse one the user has accepted.

  `scripts/check-mobile-deps.mjs` runs automatically after any install (root and
  `mobile/`) and warns about mismatches. It is advisory and never fails an
  install, since a deliberate native package is a legitimate state. If it warns
  and you did not intend a native dependency, fix it before reporting work done.
- **`expo-file-system` (SDK 54):** the default import is the new
  `File`/`Directory` API. The old function-style API (`readAsStringAsync`,
  `writeAsStringAsync`, `documentDirectory`, `downloadAsync`, …) moved to
  `expo-file-system/legacy`. Old-style calls against the default import are
  `undefined` at runtime. Pick one API and import accordingly.
- Keep `mobile/`'s `package.json` and `node_modules` separate from the web
  app's. Metro and Vite cannot share the same dependency tree.
- The Studio sandbox runs `expo start --tunnel` automatically when the user
  opens the Mobile preview tab. **Do not** add a long-running Expo process
  to the root `package.json`'s `dev` script.
- The root `package.json` has a `postinstall` that runs
  `node scripts/postinstall.mjs`. That script re-installs mobile deps whenever
  the marker exists and no-ops otherwise. Do not remove either; do not change
  the script to run unconditionally.
- Optional convenience scripts you may add at the project root:
  `"dev:mobile": "cd mobile && npm run start"`.
- API calls from the mobile app to the Modelence backend should target the
  sandbox URL exposed in the studio preview (set via an env var the user
  configures in `mobile/app.json`'s `extra` field).
- When adding shared logic, prefer plain TypeScript modules under
  `src/shared/` and import them from both the web client and the mobile app's
  `app/` screens. Avoid React-DOM-only or Node-only imports in shared code.
